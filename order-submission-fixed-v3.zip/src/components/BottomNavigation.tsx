import React, { useState } from 'react';
import { 
  Home, 
  History, 
  BarChart3, 
  MoreHorizontal,
  Plus
} from 'lucide-react';
import { useAppContext } from '../AppContext';
import { cn } from '../cn';
import { NewOrderModal } from './NewOrderModal';

export function BottomNavigation() {
  const { 
    viewStack, 
    changeTab,
    appLanguage 
  } = useAppContext();
  
  const [showAddMenu, setShowAddMenu] = useState(false);
  
  // Get the active tab (the top-most view in the viewStack)
  const currentView = viewStack[viewStack.length - 1];

  // Only show the bottom navigation bar on the top-level tab views
  const tabViews = ['home', 'history', 'customer-info', 'dashboard', 'others'];
  if (!tabViews.includes(currentView)) return null;

  return (
    <>
      <div className="w-full bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl border-t border-gray-100 dark:border-zinc-850 px-2 py-2.5 flex items-center justify-between shrink-0 z-40 pb-[calc(env(safe-area-inset-bottom)+0.6rem)] shadow-[0_-4px_20px_rgba(0,0,0,0.03)]">
        {/* TAB 1: HOME */}
        <button
          onClick={() => changeTab('home')}
          className={cn(
            "flex flex-col items-center justify-center flex-1 py-1 transition-all active:scale-95 cursor-pointer",
            currentView === 'home' ? "text-primary font-black" : "text-subtext/70 dark:text-zinc-500 font-medium"
          )}
          id="btn-nav-home"
        >
          <Home className={cn("w-5 h-5", currentView === 'home' ? "stroke-[2.5]" : "stroke-[2]")} />
          <span className="text-[9px] uppercase tracking-wider mt-1">
            {appLanguage === 'ms' ? 'Laman' : 'Home'}
          </span>
        </button>

        {/* TAB 2: ORDER */}
        <button
          onClick={() => changeTab('history')}
          className={cn(
            "flex flex-col items-center justify-center flex-1 py-1 transition-all active:scale-95 cursor-pointer",
            currentView === 'history' ? "text-primary font-black" : "text-subtext/70 dark:text-zinc-500 font-medium"
          )}
          id="btn-nav-orders"
        >
          <History className={cn("w-5 h-5", currentView === 'history' ? "stroke-[2.5]" : "stroke-[2]")} />
          <span className="text-[9px] uppercase tracking-wider mt-1">
            {appLanguage === 'ms' ? 'Tempahan' : 'Orders'}
          </span>
        </button>

        {/* TAB 3: PLUS (+) BUTTON FOR ADD ORDER */}
        <div className="flex-1 flex justify-center -mt-6">
          <button
            onClick={() => setShowAddMenu(true)}
            className="w-13 h-13 bg-primary text-white rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-transform cursor-pointer border-4 border-white dark:border-zinc-900 hover:bg-primary/95"
            id="btn-nav-add"
            aria-label="Add Order"
            title="Add Order"
          >
            <Plus className="w-6.5 h-6.5 stroke-[3]" />
          </button>
        </div>

        {/* TAB 4: BUSINESS ANALYTICS */}
        <button
          onClick={() => changeTab('dashboard')}
          className={cn(
            "flex flex-col items-center justify-center flex-1 py-1 transition-all active:scale-95 cursor-pointer",
            currentView === 'dashboard' ? "text-primary font-black" : "text-subtext/70 dark:text-zinc-500 font-medium"
          )}
          id="btn-nav-analytics"
        >
          <BarChart3 className={cn("w-5 h-5", currentView === 'dashboard' ? "stroke-[2.5]" : "stroke-[2]")} />
          <span className="text-[9px] uppercase tracking-wider mt-1">
            {appLanguage === 'ms' ? 'Analisis' : 'Analytics'}
          </span>
        </button>

        {/* TAB 5: OTHERS */}
        <button
          onClick={() => changeTab('others')}
          className={cn(
            "flex flex-col items-center justify-center flex-1 py-1 transition-all active:scale-95 cursor-pointer",
            currentView === 'others' ? "text-primary font-black" : "text-subtext/70 dark:text-zinc-500 font-medium"
          )}
          id="btn-nav-others"
        >
          <MoreHorizontal className={cn("w-5 h-5", currentView === 'others' ? "stroke-[2.5]" : "stroke-[2]")} />
          <span className="text-[9px] uppercase tracking-wider mt-1">
            {appLanguage === 'ms' ? 'Lain-lain' : 'Others'}
          </span>
        </button>
      </div>

      {/* Shared New Order Options Modal */}
      <NewOrderModal 
        isOpen={showAddMenu} 
        onClose={() => setShowAddMenu(false)} 
      />
    </>
  );
}
